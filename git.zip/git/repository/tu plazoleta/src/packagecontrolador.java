 import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import entidad.Registro_Usuario;
import modelo.ModeloRegistroUsuario;
 
 
/**
 * Servlet implementation class ServletRegistroUsuario
 */
@WebServlet("/ServletRegistroUsuario")
public class ServletRegistroUsuario extends HttpServlet {
        	private static final long serialVersionUID = 1L;
 
        	protected void service(HttpServletRequest request, HttpServletResponse response)
                               	throws ServletException, IOException {
                    	
                    	String nombre = request.getParameter("nombre");
                    	String apellido = request.getParameter("apellido");
                    	int documento = request.getIntHeader("documento");
                    	int telefono = request.getIntHeader("telefono");
                    	String email = request.getParameter("email");
                    	String contrase�a = request.getParameter("contrase�a");
                    	String c_contrase�a = request.getParameter("c_contrase�a");
 
                    	
                    	
                    	ModeloRegistroUsuario modelo = new ModeloRegistroUsuario();
                    	Registro_Usuario usuario = modelo.Enviar(nombre,apellido,documento,telefono,email, contrase�a,c_contrase�a);
 
                    	if (usuario == null) {
                               	request.setAttribute("mensaje", "Error digite todos los campos");
                               	request.getRequestDispatcher("Error.jsp").forward(request, response);
                    	
                    	
                    	} else {
                               	response.sendRedirect("principal.jsp");
                    	
                    	
                    	}
                    	
        	}
}

