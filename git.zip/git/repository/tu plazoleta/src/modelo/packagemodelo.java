package modelo;
 

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import conexion.Conexion;
import entidad.Registro_Usuario;
 
 
 
public class ModeloRegistroUsuario {
            	
            	 public Registro_Usuario Enviar (String nombre, String apellido, int documento, int telefono,String email, String contrase�a, String c_contrase�a) {
                           		
                           		Registro_Usuario usuario = null;
                           		Connection cn = null;
                           		PreparedStatement pstm = null;
                                           	ResultSet rs = null;
     	
     	
     	try {
            	 
             	cn = Conexion.getConexion();
             	String sql = "INSERT INTO accounts(naombre, apellido, documento, telefono, email, contrase�a, c_contrase�a) VALUES(?,?,?,?,?,?,?)";
             	pstm = cn.prepareStatement(sql);
             	pstm.setString(1, nombre);
             	pstm.setString(2, apellido);
             	pstm.setInt(3, documento);
             	pstm.setInt(4, telefono);
            	 pstm.setString(5, email);
             	pstm.setString(6, contrase�a);
             	pstm.setString(7, c_contrase�a);
             	rs = pstm.executeUpdate();
             	
             	
             	while (rs.next()) {
 	                                                      	usuario = new Registro_Usuario();
 	                                                      	usuario.setNombre(rs.getString("nombre"));
 	                                                      	usuario.setApellido(rs.getString("apellido"));
 	                                                      	usuario.setDocumento(rs.getInt("documento"));
 	                                                      	usuario.setTelefono(rs.getInt("telefono"));
 	       	                                           	usuario.setEmail(rs.getString("email"));
 	                                                      	usuario.setContrase�a(rs.getString("contrase�a"));
 	                                                      	usuario.setc_Contrase�a(rs.getString("c_contrase�a"));
 	                                      	}
 	                                      	
 	                      	} catch (Exception e) {
 	                                      	e.printStackTrace();
 	                      	} finally {
 	                                      	try {
 	                                                      	if (rs != null) {
 	                                                                     	rs.close();
 	                                                      	}
 	                                                      	
 	                                                      	if (pstm != null) {
 	                                                                     	pstm.close();
 	                                                      	}
 	                                                      	
 	                                                      	if (cn != null) {
 	                                                                     	cn.close();
 	                                                      	}
 	                                      	} catch (Exception e2) {
 	                                                      	e2.printStackTrace();
 	                                      	}
 	                      	}
             	
                           	return usuario;
     	
            	 }
            	
}

