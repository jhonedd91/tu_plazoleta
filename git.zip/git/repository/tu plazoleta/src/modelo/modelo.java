package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import conexion.Conexion;
import entidad.Usuario;

public class ModeloUsuario { 	
           	public Usuario iniciarSesion(String email, String contrase�a) {
                          	Usuario usuario = null;
                          	Connection cn = null;
                          	PreparedStatement pstm = null;
                          	ResultSet rs = null;
                          	
                          	try {
                                          	cn = Conexion.getConexion();
                                          	String sql = "SELECT U.idUsuario, U.email, U.contrase�a FROM usuario U WHERE U.email = ? AND U.contrase�a = ?";
                                          	pstm = cn.prepareStatement(sql);
                                          	pstm.setString(1, email);
                                          	pstm.setString(2, contrase�a);
                                          	rs = pstm.executeQuery();
                                          	
                                          	while (rs.next()) {
                                                          	usuario = new Usuario();
                                                          	usuario.setIdUsuario(rs.getInt("idUsuario"));
                                                          	usuario.setEmail(rs.getString("email"));
                                                          	usuario.setContrase�a(rs.getString("contrase�a"));
                                          	}
                                          	
                          	} catch (Exception e) {
                                          	e.printStackTrace();
                          	} finally {
                                          	try {
                                                          	if (rs != null) {
                                                                         	rs.close();
                                                          	}
                                                          	
                                                          	if (pstm != null) {
                                                                         	pstm.close();
                                                          	}
                                                          	
                                                          	if (cn != null) {
                                                                         	cn.close();
                                                          	}
                                          	} catch (Exception e2) {
                                                          	e2.printStackTrace();
                                          	}
                          	}
                          	
                          	return usuario;
           	}
}



}
